# Custom Tables - Ajax List Table #

Utility to render a Custom Tables (CT) List Table with ajax searching and pagination.

Usage:
```
ct_render_ajax_list_table( $table, $query_args = array(), $view_args = array() ) 
```

This CT plugin is already being used on [GamiPress](https://gamipress.com) to render and ajax list table on user profile with user earnings.
