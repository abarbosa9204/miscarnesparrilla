<?php
/**
 * Plain Text Email Template: Body
 *
 * This template can be overridden by copying it to yourtheme/gamipress/emails/body.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// {email} is replaced by the content entered in GamiPress > Settings > Emails

?>
{email}
